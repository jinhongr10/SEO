<?php
/**
 * Plugin Name: LensCraft AIOSEO Sync
 * Description: REST API endpoint to directly update AIOSEO title/description in wp_aioseo_posts table.
 * Version: 1.0.0
 * Author: LensCraft
 */

if (!defined('ABSPATH')) {
    exit;
}

add_action('rest_api_init', function () {
    // Update AIOSEO title and/or description for a post/product
    register_rest_route('lenscraft/v1', '/aioseo/(?P<id>\d+)', [
        'methods' => 'POST',
        'callback' => 'lenscraft_aioseo_sync_handler',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        },
    ]);

    // Read current AIOSEO data for a post/product
    register_rest_route('lenscraft/v1', '/aioseo/(?P<id>\d+)', [
        'methods' => 'GET',
        'callback' => 'lenscraft_aioseo_read_handler',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        },
    ]);
});

/**
 * Update AIOSEO title/description by writing directly to wp_aioseo_posts table.
 */
function lenscraft_aioseo_sync_handler($request) {
    global $wpdb;
    $post_id = (int) $request['id'];

    if (!get_post($post_id)) {
        return new WP_Error('not_found', 'Post not found', ['status' => 404]);
    }

    $title = $request->get_param('title');
    $description = $request->get_param('description');

    if ($title === null && $description === null) {
        return new WP_Error('no_data', 'Provide at least title or description', ['status' => 400]);
    }

    $table = $wpdb->prefix . 'aioseo_posts';

    // Check if table exists
    $table_exists = $wpdb->get_var(
        $wpdb->prepare("SHOW TABLES LIKE %s", $table)
    );
    if (!$table_exists) {
        return new WP_Error('no_aioseo', 'AIOSEO table not found. Is AIOSEO plugin installed?', ['status' => 500]);
    }

    // Check if row exists for this post
    $existing = $wpdb->get_row(
        $wpdb->prepare("SELECT id, title, description FROM {$table} WHERE post_id = %d", $post_id)
    );

    $update_data = [];
    if ($title !== null) {
        $update_data['title'] = sanitize_text_field($title);
    }
    if ($description !== null) {
        $update_data['description'] = sanitize_text_field($description);
    }
    $update_data['updated'] = current_time('mysql');

    if ($existing) {
        // Update existing row
        $result = $wpdb->update(
            $table,
            $update_data,
            ['post_id' => $post_id],
            array_fill(0, count($update_data), '%s'),
            ['%d']
        );

        if ($result === false) {
            return new WP_Error('db_error', 'Failed to update AIOSEO data: ' . $wpdb->last_error, ['status' => 500]);
        }
    } else {
        // Insert new row
        $insert_data = array_merge($update_data, [
            'post_id' => $post_id,
            'created' => current_time('mysql'),
        ]);
        $result = $wpdb->insert($table, $insert_data);

        if ($result === false) {
            return new WP_Error('db_error', 'Failed to insert AIOSEO data: ' . $wpdb->last_error, ['status' => 500]);
        }
    }

    // Read back the saved data
    $saved = $wpdb->get_row(
        $wpdb->prepare("SELECT title, description FROM {$table} WHERE post_id = %d", $post_id)
    );

    return [
        'success' => true,
        'post_id' => $post_id,
        'action' => $existing ? 'updated' : 'inserted',
        'title' => $saved ? $saved->title : '',
        'description' => $saved ? $saved->description : '',
    ];
}

/**
 * Read current AIOSEO data for a post.
 */
function lenscraft_aioseo_read_handler($request) {
    global $wpdb;
    $post_id = (int) $request['id'];

    $table = $wpdb->prefix . 'aioseo_posts';

    $table_exists = $wpdb->get_var(
        $wpdb->prepare("SHOW TABLES LIKE %s", $table)
    );
    if (!$table_exists) {
        return new WP_Error('no_aioseo', 'AIOSEO table not found', ['status' => 500]);
    }

    $row = $wpdb->get_row(
        $wpdb->prepare("SELECT title, description FROM {$table} WHERE post_id = %d", $post_id)
    );

    return [
        'post_id' => $post_id,
        'title' => $row ? $row->title : '',
        'description' => $row ? $row->description : '',
        'exists' => $row !== null,
    ];
}
