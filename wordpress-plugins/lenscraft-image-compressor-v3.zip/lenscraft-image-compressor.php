<?php
/**
 * Plugin Name: LensCraft Image Compressor
 * Description: Bulk compress media library images in-place without changing URLs or file paths.
 * Version: 1.2.0
 * Author: LensCraft
 * Text Domain: lenscraft-compressor
 */

if (!defined('ABSPATH')) {
    exit;
}

// ---------------------------------------------------------------------------
// Admin menu
// ---------------------------------------------------------------------------
add_action('admin_menu', function () {
    add_media_page(
        'Image Compressor',
        'Image Compressor',
        'manage_options',
        'lenscraft-compressor',
        'lc_compressor_page'
    );
});

// ---------------------------------------------------------------------------
// Enqueue admin assets (inline)
// ---------------------------------------------------------------------------
add_action('admin_enqueue_scripts', function ($hook) {
    if ($hook !== 'media_page_lenscraft-compressor') {
        return;
    }
    wp_enqueue_script('jquery');
});

// ---------------------------------------------------------------------------
// AJAX: get image list
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_get_images', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    $paged      = max(1, intval($_POST['paged'] ?? 1));
    $per_page   = max(1, min(200, intval($_POST['per_page'] ?? 40)));
    $min_size   = intval($_POST['min_size'] ?? 0);   // bytes
    $filter_status = sanitize_text_field($_POST['filter_status'] ?? 'all'); // all | pending | done
    $sort_by    = sanitize_text_field($_POST['sort_by'] ?? 'id'); // id | size

    $query_args = [
        'post_type'      => 'attachment',
        'post_mime_type'  => ['image/jpeg', 'image/png', 'image/webp'],
        'post_status'     => 'inherit',
        'posts_per_page'  => $per_page,
        'paged'           => $paged,
        'orderby'         => $sort_by === 'size' ? 'meta_value_num' : 'ID',
        'order'           => $sort_by === 'size' ? 'DESC' : 'DESC',
    ];

    // Filter by compression status via meta_query
    if ($filter_status === 'pending') {
        $query_args['meta_query'] = [
            'relation' => 'OR',
            ['key' => '_lc_compressed', 'compare' => 'NOT EXISTS'],
            ['key' => '_lc_compressed', 'value' => '1', 'compare' => '!='],
        ];
    } elseif ($filter_status === 'done') {
        $query_args['meta_query'] = [
            ['key' => '_lc_compressed', 'value' => '1'],
        ];
    }

    // For sorting by size, join on filesize meta
    if ($sort_by === 'size') {
        $query_args['meta_key'] = 'filesize';
    }

    $query = new WP_Query($query_args);

    $items = [];
    foreach ($query->posts as $post) {
        $file = get_attached_file($post->ID);
        if (!$file || !file_exists($file)) {
            continue;
        }
        $size = filesize($file);

        // Filter by min size (client-side pre-filter, skip small files)
        if ($min_size > 0 && $size < $min_size) {
            continue;
        }

        $compressed    = get_post_meta($post->ID, '_lc_compressed', true);
        $original_size = get_post_meta($post->ID, '_lc_original_size', true);
        $thumb         = wp_get_attachment_image_url($post->ID, 'thumbnail');

        // Count sub-sizes
        $meta = wp_get_attachment_metadata($post->ID);
        $sub_count = 0;
        $sub_total_size = 0;
        if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
            $upload_dir = dirname($file);
            foreach ($meta['sizes'] as $sz) {
                $sub_file = $upload_dir . '/' . $sz['file'];
                if (file_exists($sub_file)) {
                    $sub_count++;
                    $sub_total_size += filesize($sub_file);
                }
            }
        }

        $items[] = [
            'id'             => $post->ID,
            'title'          => $post->post_title,
            'filename'       => basename($file),
            'mime'           => $post->post_mime_type,
            'size'           => $size,
            'size_human'     => size_format($size),
            'total_size'     => $size + $sub_total_size,
            'total_human'    => size_format($size + $sub_total_size),
            'sub_count'      => $sub_count,
            'sub_size_human' => $sub_count > 0 ? size_format($sub_total_size) : '',
            'compressed'     => (bool) $compressed,
            'original_size'  => $original_size ? (int) $original_size : null,
            'saved'          => $original_size ? (int) $original_size - $size : 0,
            'thumb'          => $thumb ?: '',
        ];
    }

    wp_send_json_success([
        'items'       => $items,
        'total'       => (int) $query->found_posts,
        'total_pages' => (int) $query->max_num_pages,
        'paged'       => $paged,
    ]);
});

// ---------------------------------------------------------------------------
// AJAX: compress single image
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_compress_image', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    $id = intval($_POST['id'] ?? 0);
    if (!$id) {
        wp_send_json_error('Invalid ID');
    }

    $file = get_attached_file($id);
    if (!$file || !file_exists($file)) {
        wp_send_json_error('File not found');
    }

    $mime = get_post_mime_type($id);
    $allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!in_array($mime, $allowed, true)) {
        wp_send_json_error('Unsupported format: ' . $mime);
    }

    $quality       = intval($_POST['quality'] ?? 80);
    $quality       = max(10, min(100, $quality));
    $skip_under    = intval($_POST['skip_under'] ?? 0); // bytes, skip files smaller than this
    $convert_webp  = !empty($_POST['convert_webp']);

    $original_size = filesize($file);
    $total_saved   = 0;
    $main_skipped  = false;
    $subs_compressed = 0;
    $subs_skipped    = 0;

    // --- Compress main file ---
    if ($skip_under > 0 && $original_size < $skip_under) {
        $main_skipped = true;
    } else {
        $result = lc_compress_file($file, $mime, $quality, $convert_webp);
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        $main_skipped = ($result === 'skipped');
        if (!$main_skipped) {
            $total_saved += $original_size - filesize($file);
        }
    }

    $new_size = filesize($file);

    // --- Compress sub-sizes (thumbnail, medium, large, etc.) ---
    $meta = wp_get_attachment_metadata($id);
    if (!empty($meta['sizes']) && is_array($meta['sizes'])) {
        $upload_dir = dirname($file);
        foreach ($meta['sizes'] as $size_key => $size_info) {
            $sub_file = $upload_dir . '/' . $size_info['file'];
            if (!file_exists($sub_file)) {
                continue;
            }
            $sub_original = filesize($sub_file);

            // Skip small sub-sizes
            if ($skip_under > 0 && $sub_original < $skip_under) {
                $subs_skipped++;
                continue;
            }

            // Determine mime from extension
            $sub_ext  = strtolower(pathinfo($sub_file, PATHINFO_EXTENSION));
            $sub_mime = $mime; // default to parent mime
            if (in_array($sub_ext, ['jpg', 'jpeg'])) $sub_mime = 'image/jpeg';
            elseif ($sub_ext === 'png') $sub_mime = 'image/png';
            elseif ($sub_ext === 'webp') $sub_mime = 'image/webp';

            $sub_result = lc_compress_file($sub_file, $sub_mime, $quality, $convert_webp);
            if ($sub_result === true) {
                $sub_new = filesize($sub_file);
                $total_saved += $sub_original - $sub_new;
                // Update sub-size filesize in metadata
                $meta['sizes'][$size_key]['filesize'] = $sub_new;
                $subs_compressed++;
            } else {
                $subs_skipped++;
            }
        }
    }

    // Mark as compressed
    update_post_meta($id, '_lc_compressed', 1);
    update_post_meta($id, '_lc_original_size', $original_size);
    update_post_meta($id, '_lc_compressed_at', current_time('mysql'));

    // Update attachment metadata
    if ($meta) {
        $meta['filesize'] = $new_size;
        wp_update_attachment_metadata($id, $meta);
    }

    // Update mime type in posts table to indicate it's now WebP
    if ($convert_webp && in_array($mime, ['image/jpeg', 'image/png'], true) && !$main_skipped) {
        global $wpdb;
        $wpdb->update($wpdb->posts, ['post_mime_type' => 'image/webp'], ['ID' => $id]);
    }

    wp_send_json_success([
        'id'               => $id,
        'original_size'    => $original_size,
        'new_size'         => $new_size,
        'saved'            => $total_saved,
        'saved_pct'        => $original_size > 0 ? round(($original_size - $new_size) / $original_size * 100, 1) : 0,
        'size_human'       => size_format($new_size),
        'skipped'          => $main_skipped && $subs_compressed === 0,
        'subs_compressed'  => $subs_compressed,
        'subs_skipped'     => $subs_skipped,
    ]);
});

// ---------------------------------------------------------------------------
// AJAX: get stats
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_get_stats', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    global $wpdb;

    $total = (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type='attachment' AND post_mime_type IN ('image/jpeg','image/png','image/webp') AND post_status='inherit'"
    );

    $compressed = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} WHERE meta_key = %s AND meta_value = %s",
            '_lc_compressed',
            '1'
        )
    );

    $total_saved = (int) $wpdb->get_var(
        $wpdb->prepare(
            "SELECT COALESCE(SUM(CAST(orig.meta_value AS UNSIGNED) - CAST(cur.meta_value AS UNSIGNED)), 0)
             FROM {$wpdb->postmeta} orig
             JOIN {$wpdb->postmeta} cur ON orig.post_id = cur.post_id AND cur.meta_key = '_lc_compressed'
             JOIN {$wpdb->postmeta} fs ON orig.post_id = fs.post_id
             WHERE orig.meta_key = %s AND cur.meta_value = %s",
            '_lc_original_size',
            '1'
        )
    );

    // Recalculate saved from actual meta values
    $rows = $wpdb->get_results(
        $wpdb->prepare(
            "SELECT orig.meta_value as orig_size, orig.post_id
             FROM {$wpdb->postmeta} orig
             JOIN {$wpdb->postmeta} comp ON orig.post_id = comp.post_id AND comp.meta_key = %s AND comp.meta_value = %s
             WHERE orig.meta_key = %s",
            '_lc_compressed', '1', '_lc_original_size'
        )
    );
    $saved = 0;
    foreach ($rows as $row) {
        $f = get_attached_file($row->post_id);
        if ($f && file_exists($f)) {
            $saved += max(0, (int) $row->orig_size - filesize($f));
        }
    }

    wp_send_json_success([
        'total'       => $total,
        'compressed'  => $compressed,
        'uncompressed'=> $total - $compressed,
        'saved_bytes' => $saved,
        'saved_human' => size_format($saved),
    ]);
});

// ---------------------------------------------------------------------------
// Core compression function
// ---------------------------------------------------------------------------
function lc_compress_file($file, $mime, $quality = 80, $convert_webp = false) {
    $tmp = $file . '.lc_tmp';

    $editor = wp_get_image_editor($file);
    if (is_wp_error($editor)) {
        return $editor;
    }

    $editor->set_quality($quality);

    // Determine save mime type
    $save_mime = null;
    if ($convert_webp && in_array($mime, ['image/jpeg', 'image/png'], true)) {
        $save_mime = 'image/webp';
    } else {
        switch ($mime) {
            case 'image/jpeg':
                $save_mime = 'image/jpeg';
                break;
            case 'image/png':
                $save_mime = 'image/png';
                break;
            case 'image/webp':
                $save_mime = 'image/webp';
                break;
            default:
                return new WP_Error('unsupported', 'Unsupported format');
        }
    }

    $saved = $editor->save($tmp, $save_mime);
    if (is_wp_error($saved)) {
        @unlink($tmp);
        return $saved;
    }

    $tmp_path = $saved['path'];
    $new_size = filesize($tmp_path);
    $old_size = filesize($file);

    // Only replace if smaller
    if ($new_size < $old_size) {
        // Replace original
        if (!@rename($tmp_path, $file)) {
            @copy($tmp_path, $file);
            @unlink($tmp_path);
        }
        return true;
    }

    // Compressed version is larger or same, discard it
    @unlink($tmp_path);
    return 'skipped';
}

// ---------------------------------------------------------------------------
// Admin page
// ---------------------------------------------------------------------------
function lc_compressor_page() {
    $nonce = wp_create_nonce('lc_compressor_nonce');
    ?>
    <style>
        .lc-wrap { max-width: 1200px; }
        .lc-stats { display: flex; gap: 16px; margin: 20px 0; flex-wrap: wrap; }
        .lc-stat-card {
            background: #fff; border: 1px solid #c3c4c7; border-radius: 4px;
            padding: 16px 24px; min-width: 150px; text-align: center;
        }
        .lc-stat-card .number { font-size: 28px; font-weight: 700; color: #1d2327; }
        .lc-stat-card .label { font-size: 13px; color: #646970; margin-top: 4px; }
        .lc-controls { margin: 20px 0; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; }
        .lc-progress-wrap {
            display: none; margin: 16px 0; background: #fff;
            border: 1px solid #c3c4c7; border-radius: 4px; padding: 16px;
        }
        .lc-progress-bar {
            height: 24px; background: #f0f0f1; border-radius: 3px; overflow: hidden;
        }
        .lc-progress-fill {
            height: 100%; background: #2271b1; transition: width 0.3s; width: 0%;
            display: flex; align-items: center; justify-content: center;
            color: #fff; font-size: 12px; font-weight: 600; min-width: 40px;
        }
        .lc-progress-text { margin-top: 8px; font-size: 13px; color: #646970; }
        .lc-table { width: 100%; border-collapse: collapse; background: #fff; border: 1px solid #c3c4c7; }
        .lc-table th { background: #f6f7f7; text-align: left; padding: 10px 12px; font-size: 13px; border-bottom: 1px solid #c3c4c7; }
        .lc-table td { padding: 8px 12px; border-bottom: 1px solid #f0f0f1; font-size: 13px; vertical-align: middle; }
        .lc-table tr:hover td { background: #f6f7f7; }
        .lc-thumb { width: 50px; height: 50px; object-fit: cover; border-radius: 3px; }
        .lc-badge {
            display: inline-block; padding: 2px 8px; border-radius: 3px;
            font-size: 12px; font-weight: 500;
        }
        .lc-badge-done { background: #d4edda; color: #155724; }
        .lc-badge-pending { background: #fff3cd; color: #856404; }
        .lc-badge-skipped { background: #e2e3e5; color: #383d41; }
        .lc-saved { color: #00a32a; font-weight: 600; }
        .lc-sub-info { font-size: 11px; color: #646970; }
        .lc-table th.lc-cb, .lc-table td.lc-cb { width: 30px; text-align: center; }
        .lc-table input[type=checkbox] { margin: 0; cursor: pointer; width: 16px; height: 16px; }
        .lc-select-bar { display: none; margin: 8px 0; padding: 8px 14px; background: #f0f6fc; border: 1px solid #72aee6; border-radius: 4px; font-size: 13px; align-items: center; gap: 10px; }
        .lc-select-bar.visible { display: flex; }
        .lc-filters { margin: 12px 0; display: flex; gap: 12px; align-items: center; flex-wrap: wrap; background: #fff; border: 1px solid #c3c4c7; border-radius: 4px; padding: 12px 16px; }
        .lc-filters label { font-size: 13px; }
        .lc-filters select, .lc-filters input[type=number] { margin-left: 4px; }
        .lc-pagination { margin: 16px 0; display: flex; gap: 8px; align-items: center; flex-wrap: wrap; }
        .lc-log { max-height: 200px; overflow-y: auto; font-size: 12px; font-family: monospace; margin-top: 10px; background: #f6f7f7; padding: 8px; border-radius: 3px; }
        .lc-log-line { padding: 2px 0; }
        .lc-log-line.error { color: #d63638; }
        .lc-log-line.success { color: #00a32a; }
        .lc-log-line.skip { color: #996800; }

        /* Modal Styles */
        .lc-modal {
            display: none; position: fixed; z-index: 100000; left: 0; top: 0; width: 100%; height: 100%;
            background-color: rgba(0,0,0,0.8);
        }
        .lc-modal-content {
            background-color: #fff; margin: 4% auto; padding: 24px; width: 90%; max-width: 900px;
            border-radius: 4px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); position: relative;
            max-height: 85vh; overflow-y: auto; box-sizing: border-box;
        }
        .lc-modal-close {
            color: #646970; float: right; font-size: 28px; font-weight: bold; cursor: pointer;
            line-height: 1; margin-top: -10px; margin-right: -10px;
        }
        .lc-modal-close:hover { color: #d63638; }
        .lc-compare-grid {
            display: flex; gap: 20px; margin-top: 16px;
        }
        .lc-compare-col {
            flex: 1; text-align: center;
        }
        .lc-compare-col img {
            max-width: 100%; max-height: 50vh; border: 1px solid #c3c4c7; border-radius: 4px; object-fit: contain; background: #f0f0f1;
        }
        .lc-compare-info {
            font-size: 14px; margin-top: 8px; font-weight: 500;
        }
        .lc-preview-loading { display: none; text-align: center; padding: 40px; font-size: 16px; }
    </style>

    <div class="wrap lc-wrap">
        <h1>LensCraft Image Compressor</h1>
        <p>Compress media library images in their original format. File paths and URLs remain unchanged.</p>

        <div class="lc-stats" id="lc-stats">
            <div class="lc-stat-card"><div class="number" id="stat-total">-</div><div class="label">Total Images</div></div>
            <div class="lc-stat-card"><div class="number" id="stat-compressed">-</div><div class="label">Compressed</div></div>
            <div class="lc-stat-card"><div class="number" id="stat-uncompressed">-</div><div class="label">Pending</div></div>
            <div class="lc-stat-card"><div class="number" id="stat-saved">-</div><div class="label">Total Saved</div></div>
        </div>

        <div class="lc-controls">
            <label>Quality: <input type="number" id="lc-quality" value="80" min="10" max="100" style="width:60px"> <small>(10-100)</small></label>
            <label><input type="checkbox" id="lc-convert-webp" value="1" checked> <b>Convert to WebP</b> <small>(in-place)</small></label>
            <label>Skip under: <select id="lc-skip-under">
                <option value="0">No skip</option>
                <option value="10240" selected>10 KB</option>
                <option value="20480">20 KB</option>
                <option value="51200">50 KB</option>
            </select></label>
            <button class="button button-primary" id="btn-compress-all">Compress All Pending</button>
            <button class="button" id="btn-convert-all-webp" style="background:#00a32a;color:#fff;border-color:#008a20;">Convert All to WebP</button>
            <button class="button button-primary" id="btn-compress-selected" style="display:none;">Compress Selected (<span id="selected-count">0</span>)</button>
            <button class="button" id="btn-stop" style="display:none;">Stop</button>
            <button class="button" id="btn-refresh">Refresh</button>
        </div>

        <div class="lc-filters">
            <label>Status: <select id="filter-status">
                <option value="all">All</option>
                <option value="pending">Pending</option>
                <option value="done">Done</option>
            </select></label>
            <label>Min size: <select id="filter-min-size">
                <option value="0">All sizes</option>
                <option value="51200">&#8805; 50 KB</option>
                <option value="102400">&#8805; 100 KB</option>
                <option value="204800">&#8805; 200 KB</option>
                <option value="512000">&#8805; 500 KB</option>
                <option value="1048576">&#8805; 1 MB</option>
            </select></label>
            <label>Sort: <select id="filter-sort">
                <option value="id">Newest first</option>
                <option value="size">Largest first</option>
            </select></label>
            <label>Per page: <select id="filter-per-page">
                <option value="10">10</option>
                <option value="20">20</option>
                <option value="40" selected>40</option>
                <option value="100">100</option>
            </select></label>
            <button class="button" id="btn-apply-filter">Apply Filter</button>
        </div>

        <div class="lc-progress-wrap" id="lc-progress">
            <div class="lc-progress-bar"><div class="lc-progress-fill" id="lc-progress-fill">0%</div></div>
            <div class="lc-progress-text" id="lc-progress-text">Preparing...</div>
            <div class="lc-log" id="lc-log"></div>
        </div>

        <table class="lc-table">
            <thead>
                <tr>
                    <th class="lc-cb"><input type="checkbox" id="cb-select-all" title="Select all"></th>
                    <th></th>
                    <th>File</th>
                    <th>Format</th>
                    <th>Main Size</th>
                    <th>Sub-sizes</th>
                    <th>Status</th>
                    <th>Saved</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="lc-tbody"><tr><td colspan="9" style="text-align:center;padding:30px;">Loading...</td></tr></tbody>
        </table>

        <div class="lc-pagination" id="lc-pagination"></div>
    </div>

    <!-- Preview Modal -->
    <div id="lc-preview-modal" class="lc-modal">
        <div class="lc-modal-content">
            <span class="lc-modal-close">&times;</span>
            <h2>Image Preview</h2>
            <div id="lc-preview-loading" class="lc-preview-loading">Generating preview...</div>
            <div id="lc-preview-body" style="display:none;">
                <div style="text-align:center;font-size:16px;font-weight:bold;margin-bottom:10px;" id="lc-preview-saved-text"></div>
                <div class="lc-compare-grid">
                    <div class="lc-compare-col">
                        <h3>Original</h3>
                        <img id="lc-preview-img-orig" src="">
                        <div class="lc-compare-info" id="lc-preview-info-orig"></div>
                    </div>
                    <div class="lc-compare-col">
                        <h3>Compressed</h3>
                        <img id="lc-preview-img-new" src="">
                        <div class="lc-compare-info" id="lc-preview-info-new"></div>
                    </div>
                </div>
                <div style="text-align:right; margin-top:20px;">
                    <button class="button button-primary" id="lc-preview-btn-compress">Apply Compression</button>
                    <button class="button lc-modal-close-btn" style="margin-left:8px;">Cancel</button>
                </div>
            </div>
        </div>
    </div>

    <script>
    (function($) {
        const nonce = '<?php echo esc_js($nonce); ?>';
        const ajaxurl = '<?php echo esc_js(admin_url("admin-ajax.php")); ?>';
        let currentPage = 1;
        let stopFlag = false;

        function formatSize(bytes) {
            if (bytes <= 0) return '0 B';
            const units = ['B', 'KB', 'MB', 'GB'];
            let i = 0, v = bytes;
            while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
            return v.toFixed(i === 0 ? 0 : 1) + ' ' + units[i];
        }

        function formatMime(m) {
            return m.replace('image/', '').toUpperCase();
        }

        function getFilters() {
            return {
                filter_status: $('#filter-status').val(),
                min_size: $('#filter-min-size').val(),
                sort_by: $('#filter-sort').val(),
                per_page: $('#filter-per-page').val(),
            };
        }

        // --- Selection helpers ---
        function getSelectedIds() {
            const ids = [];
            $('.lc-row-cb:checked').each(function() { ids.push(parseInt($(this).val())); });
            return ids;
        }

        function updateSelectionUI() {
            const count = getSelectedIds().length;
            $('#selected-count').text(count);
            if (count > 0) {
                $('#btn-compress-selected').show();
            } else {
                $('#btn-compress-selected').hide();
            }
            // Sync "select all" checkbox
            const total = $('.lc-row-cb').length;
            $('#cb-select-all').prop('checked', total > 0 && count === total);
        }

        function loadStats() {
            $.post(ajaxurl, { action: 'lc_get_stats', nonce: nonce }, function(res) {
                if (!res.success) return;
                const d = res.data;
                $('#stat-total').text(d.total);
                $('#stat-compressed').text(d.compressed);
                $('#stat-uncompressed').text(d.uncompressed);
                $('#stat-saved').text(d.saved_human);
            });
        }

        function loadImages(page) {
            currentPage = page || 1;
            const f = getFilters();
            $.post(ajaxurl, {
                action: 'lc_get_images', nonce: nonce, paged: currentPage,
                filter_status: f.filter_status, min_size: f.min_size, sort_by: f.sort_by, per_page: f.per_page,
            }, function(res) {
                if (!res.success) return;
                const d = res.data;
                const $tbody = $('#lc-tbody').empty();
                $('#cb-select-all').prop('checked', false);

                if (!d.items.length) {
                    $tbody.html('<tr><td colspan="9" style="text-align:center;padding:30px;">No images found</td></tr>');
                    updateSelectionUI();
                    return;
                }

                d.items.forEach(function(item) {
                    const status = item.compressed
                        ? '<span class="lc-badge lc-badge-done">Done</span>'
                        : '<span class="lc-badge lc-badge-pending">Pending</span>';
                    const saved = item.compressed && item.original_size
                        ? '<span class="lc-saved">-' + formatSize(item.saved) + ' (' + (item.original_size > 0 ? ((item.saved / item.original_size) * 100).toFixed(1) : 0) + '%)</span>'
                        : '-';
                    
                    let btn = '';
                    if (item.compressed) {
                        btn = '<button class="button button-small btn-recompress" data-id="' + item.id + '">Re-compress</button>';
                        btn += ' <button class="button button-small btn-preview" data-id="' + item.id + '">Preview</button>';
                    } else {
                        btn = '<button class="button button-primary button-small btn-single" data-id="' + item.id + '">Compress</button>';
                        btn += ' <button class="button button-small btn-preview" data-id="' + item.id + '">Preview</button>';
                    }

                    const thumb = item.thumb ? '<img class="lc-thumb" src="' + item.thumb + '" loading="lazy">' : '';
                    const subInfo = item.sub_count > 0
                        ? item.sub_count + ' files (' + item.sub_size_human + ')'
                        : '<span style="color:#999">-</span>';

                    $tbody.append(
                        '<tr id="row-' + item.id + '">' +
                        '<td class="lc-cb"><input type="checkbox" class="lc-row-cb" value="' + item.id + '"></td>' +
                        '<td>' + thumb + '</td>' +
                        '<td title="' + item.filename + '">' + (item.filename.length > 35 ? item.filename.substring(0, 32) + '...' : item.filename) + '</td>' +
                        '<td>' + formatMime(item.mime) + '</td>' +
                        '<td>' + item.size_human + '</td>' +
                        '<td class="lc-sub-info">' + subInfo + '</td>' +
                        '<td class="td-status">' + status + '</td>' +
                        '<td class="td-saved">' + saved + '</td>' +
                        '<td>' + btn + '</td>' +
                        '</tr>'
                    );
                });

                updateSelectionUI();

                // Pagination
                const $pag = $('#lc-pagination').empty();
                if (d.total_pages > 1) {
                    const maxShow = 10;
                    let start = Math.max(1, d.paged - Math.floor(maxShow / 2));
                    let end = Math.min(d.total_pages, start + maxShow - 1);
                    if (end - start < maxShow - 1) start = Math.max(1, end - maxShow + 1);

                    if (start > 1) {
                        $pag.append('<button class="button btn-page" data-page="1">1</button>');
                        if (start > 2) $pag.append('<span style="padding:0 4px">...</span>');
                    }
                    for (let p = start; p <= end; p++) {
                        const cls = p === d.paged ? 'button button-primary' : 'button';
                        $pag.append('<button class="' + cls + ' btn-page" data-page="' + p + '">' + p + '</button>');
                    }
                    if (end < d.total_pages) {
                        if (end < d.total_pages - 1) $pag.append('<span style="padding:0 4px">...</span>');
                        $pag.append('<button class="button btn-page" data-page="' + d.total_pages + '">' + d.total_pages + '</button>');
                    }
                    $pag.append('<span style="margin-left:8px;color:#646970;font-size:13px">(' + d.total + ' total)</span>');
                }
            });
        }

        function compressSingle(id, callback) {
            const quality = parseInt($('#lc-quality').val()) || 80;
            const skipUnder = parseInt($('#lc-skip-under').val()) || 0;
            const convertWebp = $('#lc-convert-webp').prop('checked') ? 1 : 0;
            $.post(ajaxurl, {
                action: 'lc_compress_image', nonce: nonce,
                id: id, quality: quality, skip_under: skipUnder, convert_webp: convertWebp
            }, function(res) {
                if (callback) callback(res);
            }).fail(function() {
                if (callback) callback({ success: false, data: 'Request failed' });
            });
        }

        function updateRowAfterCompress(id, res, $btn) {
            if (res.success) {
                const d = res.data;
                const $row = $('#row-' + id);
                if (d.skipped) {
                    $row.find('.td-status').html('<span class="lc-badge lc-badge-skipped">Already optimal</span>');
                } else {
                    let label = 'Done';
                    if (d.subs_compressed > 0) label += ' +' + d.subs_compressed + ' subs';
                    $row.find('.td-status').html('<span class="lc-badge lc-badge-done">' + label + '</span>');
                    $row.find('.td-saved').html('<span class="lc-saved">-' + formatSize(d.saved) + ' (' + d.saved_pct + '%)</span>');
                }
                $row.find('td:eq(4)').text(d.size_human);
                if ($btn) $btn.replaceWith('<button class="button button-small btn-recompress" data-id="' + id + '">Re-compress</button>');
                loadStats();
            } else {
                if ($btn) { 
                    $btn.prop('disabled', false).text('Re-compress'); 
                    $btn.siblings('.btn-preview').show(); // Show preview again if it was hidden
                }
                alert('Error: ' + (res.data || 'Unknown error'));
            }
        }

        // --- Preview Logic ---
        let currentPreviewId = null;

        $(document).on('click', '.btn-preview', function() {
            const id = $(this).data('id');
            currentPreviewId = id;
            
            $('#lc-preview-modal').show();
            $('#lc-preview-loading').show();
            $('#lc-preview-body').hide();
            
            const quality = parseInt($('#lc-quality').val()) || 80;
            const convertWebp = $('#lc-convert-webp').prop('checked') ? 1 : 0;
            
            $.post(ajaxurl, {
                action: 'lc_preview_image', nonce: nonce,
                id: id, quality: quality, convert_webp: convertWebp
            }, function(res) {
                $('#lc-preview-loading').hide();
                if (!res.success) {
                    alert('Preview error: ' + (res.data || 'Unknown error'));
                    $('#lc-preview-modal').hide();
                    return;
                }
                
                const d = res.data;
                $('#lc-preview-body').show();
                $('#lc-preview-saved-text').text('Saved ' + d.saved_human + ' (' + d.saved_pct + '%)');
                
                $('#lc-preview-img-orig').attr('src', d.original_url);
                $('#lc-preview-info-orig').text('Size: ' + d.original_size_human);
                
                $('#lc-preview-img-new').attr('src', d.preview_data_uri);
                $('#lc-preview-info-new').text('Size: ' + d.new_size_human);
            }).fail(function() {
                $('#lc-preview-loading').hide();
                alert('Network error while generating preview');
                $('#lc-preview-modal').hide();
            });
        });

        $('.lc-modal-close, .lc-modal-close-btn').on('click', function() {
            $('#lc-preview-modal').hide();
            $('#lc-preview-img-orig').attr('src', '');
            $('#lc-preview-img-new').attr('src', '');
        });

        $('#lc-preview-btn-compress').on('click', function() {
            $('#lc-preview-modal').hide();
            if (currentPreviewId) {
                const $btn = $('.btn-single[data-id="' + currentPreviewId + '"], .btn-recompress[data-id="' + currentPreviewId + '"]');
                if($btn.length) {
                    $btn.click();
                } else {
                    compressSingle(currentPreviewId, function(res) {
                        if(res.success) { loadImages(currentPage); loadStats(); }
                        else alert('Error: ' + res.data);
                    });
                }
            }
        });

        // --- Select all checkbox ---
        $(document).on('change', '#cb-select-all', function() {
            const checked = $(this).prop('checked');
            $('.lc-row-cb').prop('checked', checked);
            updateSelectionUI();
        });

        // --- Individual checkbox ---
        $(document).on('change', '.lc-row-cb', function() {
            updateSelectionUI();
        });

        // --- Single compress button ---
        $(document).on('click', '.btn-single, .btn-recompress', function() {
            const $btn = $(this);
            const id = $btn.data('id');
            $btn.prop('disabled', true).text('...');
            $btn.siblings('.btn-preview').hide(); // hide preview during compress
            compressSingle(id, function(res) { 
                updateRowAfterCompress(id, res, $btn); 
                // Re-add preview button
                const $newBtn = $('#row-' + id).find('.btn-recompress');
                if($newBtn.length && !$newBtn.siblings('.btn-preview').length) {
                    $newBtn.after(' <button class="button button-small btn-preview" data-id="' + id + '">Preview</button>');
                }
            });
        });

        // --- Batch compress: run a list of IDs through progress UI ---
        function runBatchCompress(ids, label) {
            stopFlag = false;
            $('#lc-progress').show();
            const $log = $('#lc-log').empty();
            const $btnAll = $('#btn-compress-all').hide();
            const $btnSelected = $('#btn-compress-selected').hide();
            const $btnStop = $('#btn-stop').show().prop('disabled', false).text('Stop');

            if (!ids.length) {
                $log.append('<div class="lc-log-line">No images to compress.</div>');
                $btnAll.show();
                $btnStop.hide();
                updateSelectionUI();
                return;
            }

            let i = 0;
            let totalSaved = 0;

            function next() {
                if (stopFlag || i >= ids.length) {
                    const msg = stopFlag ? 'Stopped.' : 'All done!';
                    const pct = ids.length > 0 ? 100 : 0;
                    $('#lc-progress-fill').css('width', pct + '%').text(pct + '%');
                    $('#lc-progress-text').text(msg + ' Processed: ' + i + '/' + ids.length + ', Total saved: ' + formatSize(totalSaved));
                    $btnAll.show();
                    $btnStop.hide();
                    loadImages(currentPage);
                    loadStats();
                    return;
                }

                const id = ids[i];
                const pct = Math.round((i / ids.length) * 100);
                $('#lc-progress-fill').css('width', pct + '%').text(pct + '%');
                $('#lc-progress-text').text(label + ' ' + (i + 1) + ' / ' + ids.length + '...');

                compressSingle(id, function(res) {
                    i++;
                    if (res.success) {
                        const d = res.data;
                        if (d.skipped) {
                            $log.prepend('<div class="lc-log-line skip">#' + id + ' already optimal</div>');
                        } else {
                            totalSaved += d.saved;
                            let msg = '#' + id + ' -' + formatSize(d.saved) + ' (' + d.saved_pct + '%)';
                            if (d.subs_compressed > 0) msg += ' [+' + d.subs_compressed + ' sub-sizes]';
                            $log.prepend('<div class="lc-log-line success">' + msg + '</div>');
                        }
                    } else {
                        $log.prepend('<div class="lc-log-line error">#' + id + ' ERROR: ' + (res.data || 'unknown') + '</div>');
                    }
                    next();
                });
            }

            next();
        }

        // --- Compress All Pending ---
        $('#btn-compress-all').on('click', function() {
            if (!confirm('Start compressing all pending images (including their sub-sizes)?')) return;
            $.post(ajaxurl, { action: 'lc_get_all_uncompressed', nonce: nonce }, function(res) {
                if (!res.success) return;
                runBatchCompress(res.data.ids, 'Processing');
            });
        });

        // --- Convert All to WebP ---
        $('#btn-convert-all-webp').on('click', function() {
            if (!confirm('Start converting ALL JPEG/PNG images to WebP? (This will process previously compressed images too)')) return;
            $('#lc-convert-webp').prop('checked', true); // ensure checkbox is checked
            $.post(ajaxurl, { action: 'lc_get_all_legacy', nonce: nonce }, function(res) {
                if (!res.success) return;
                runBatchCompress(res.data.ids, 'Converting');
            });
        });

        // --- Compress Selected ---
        $('#btn-compress-selected').on('click', function() {
            const ids = getSelectedIds();
            if (!ids.length) return;
            if (!confirm('Compress ' + ids.length + ' selected images?')) return;
            runBatchCompress(ids, 'Compressing selected');
        });

        // Stop button
        $('#btn-stop').on('click', function() {
            stopFlag = true;
            $(this).prop('disabled', true).text('Stopping...');
        });

        // Filter apply
        $('#btn-apply-filter').on('click', function() {
            loadImages(1);
        });

        // Refresh
        $('#btn-refresh').on('click', function() {
            loadImages(currentPage);
            loadStats();
        });

        // Page navigation
        $(document).on('click', '.btn-page', function() {
            loadImages($(this).data('page'));
        });

        // Init
        loadStats();
        loadImages(1);
    })(jQuery);
    </script>
    <?php
}

// ---------------------------------------------------------------------------
// AJAX: get all uncompressed image IDs (for batch)
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_get_all_uncompressed', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    global $wpdb;

    $ids = $wpdb->get_col(
        "SELECT p.ID FROM {$wpdb->posts} p
         LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_lc_compressed'
         WHERE p.post_type = 'attachment'
           AND p.post_mime_type IN ('image/jpeg','image/png','image/webp')
           AND p.post_status = 'inherit'
           AND (pm.meta_value IS NULL OR pm.meta_value != '1')
         ORDER BY p.ID ASC"
    );

    wp_send_json_success(['ids' => array_map('intval', $ids)]);
});

// ---------------------------------------------------------------------------
// AJAX: get all legacy image IDs (for webp convert)
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_get_all_legacy', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    global $wpdb;

    $ids = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts}
         WHERE post_type = 'attachment'
           AND post_mime_type IN ('image/jpeg','image/png')
           AND post_status = 'inherit'
         ORDER BY ID ASC"
    );

    wp_send_json_success(['ids' => array_map('intval', $ids)]);
});

// ---------------------------------------------------------------------------
// AJAX: generate preview for a single image (returns base64)
// ---------------------------------------------------------------------------
add_action('wp_ajax_lc_preview_image', function () {
    check_ajax_referer('lc_compressor_nonce', 'nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Permission denied');
    }

    $id = intval($_POST['id'] ?? 0);
    $quality = max(10, min(100, intval($_POST['quality'] ?? 80)));
    $convert_webp = !empty($_POST['convert_webp']);

    if (!$id) {
        wp_send_json_error('Invalid ID');
    }

    $file = get_attached_file($id);
    if (!$file || !file_exists($file)) {
        wp_send_json_error('File not found');
    }

    $mime = get_post_mime_type($id);
    $original_size = filesize($file);
    
    $temp_filename = wp_tempnam($file);
    if (!$temp_filename) {
        wp_send_json_error('Could not create temp file');
    }

    $editor = wp_get_image_editor($file);
    if (is_wp_error($editor)) {
        @unlink($temp_filename);
        wp_send_json_error($editor->get_error_message());
    }

    $editor->set_quality($quality);

    $save_mime = null;
    if ($convert_webp && in_array($mime, ['image/jpeg', 'image/png'], true)) {
        $save_mime = 'image/webp';
    } else {
        switch ($mime) {
            case 'image/jpeg': $save_mime = 'image/jpeg'; break;
            case 'image/png': $save_mime = 'image/png'; break;
            case 'image/webp': $save_mime = 'image/webp'; break;
            default:
                @unlink($temp_filename);
                wp_send_json_error('Unsupported format');
        }
    }

    $saved = $editor->save($temp_filename, $save_mime);
    if (is_wp_error($saved)) {
        @unlink($temp_filename);
        wp_send_json_error($saved->get_error_message());
    }

    $tmp_path = $saved['path'];
    $new_size = filesize($tmp_path);
    
    // Generate base64
    $data = file_get_contents($tmp_path);
    $base64 = base64_encode($data);
    $data_uri = 'data:' . $saved['mime-type'] . ';base64,' . $base64;

    @unlink($temp_filename);
    @unlink($tmp_path);

    $original_url = wp_get_attachment_url($id);

    wp_send_json_success([
        'original_size' => $original_size,
        'original_size_human' => size_format($original_size),
        'new_size' => $new_size,
        'new_size_human' => size_format($new_size),
        'saved' => max(0, $original_size - $new_size),
        'saved_human' => size_format(max(0, $original_size - $new_size)),
        'saved_pct' => $original_size > 0 ? round((max(0, $original_size - $new_size) / $original_size) * 100, 1) : 0,
        'original_url' => $original_url,
        'preview_data_uri' => $data_uri
    ]);
});
